const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');
let currentInput = '';
let resultDisplayed = false;

// Safe calculation function
function calculate(expression) {
  try {
    expression = expression.replace(/×/g, '*').replace(/÷/g, '/');
    if (/[^0-9+\-*/.]/.test(expression)) return 'Error';
    return Function(`return ${expression}`)();
  } catch {
    return 'Error';
  }
}

// Button click events
buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.getAttribute('data-value');

    if (button.id === 'clear') {
      currentInput = '';
      display.textContent = '0';
    } else if (button.id === 'backspace') {
      currentInput = currentInput.slice(0, -1);
      display.textContent = currentInput || '0';
    } else if (button.id === 'equals') {
      const result = calculate(currentInput);
      display.textContent = result;
      currentInput = result.toString();
      resultDisplayed = true;
    } else {
      if (resultDisplayed) {
        currentInput = '';
        resultDisplayed = false;
      }
      currentInput += value;
      display.textContent = currentInput;
    }
  });
});

// Keyboard support
document.addEventListener('keydown', (e) => {
  const allowedKeys = '0123456789+-*/.';
  if (allowedKeys.includes(e.key)) {
    if (resultDisplayed) {
      currentInput = '';
      resultDisplayed = false;
    }
    currentInput += e.key;
    display.textContent = currentInput;
  } else if (e.key === 'Enter') {
    const result = calculate(currentInput);
    display.textContent = result;
    currentInput = result.toString();
    resultDisplayed = true;
  } else if (e.key === 'Backspace') {
    currentInput = currentInput.slice(0, -1);
    display.textContent = currentInput || '0';
  } else if (e.key.toLowerCase() === 'c') {
    currentInput = '';
    display.textContent = '0';
  }
});
